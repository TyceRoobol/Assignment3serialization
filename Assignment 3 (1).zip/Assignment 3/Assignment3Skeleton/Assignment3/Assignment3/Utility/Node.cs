﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.Serialization;
using System.Xml.Serialization;
using System.Runtime.Serialization.Formatters.Binary;

namespace Assignment3
{
    [Serializable]
    public class Node
    {
        public User user {  get; set; }
        public Node Next { get; set; }
        public Node(User data)
        {
            this.user = data;
        }
    }
}
