﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.Remoting.Messaging;
using System.Runtime.Serialization;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.Serialization.Formatters.Binary;

namespace Assignment3
{
    [Serializable]
    public class SLL : ILinkedListADT
    {
        public Node Head {  get; private set; }
        public Node Tail { get; private set; }
        public int Counter { get; private set; }
        public SLL() 
        {
            Head = null;
            Tail = null;
            Counter = 0;
        }
        public bool IsEmpty()
        {
            if (Head == null && Counter == 0)
            {
                return true;
            } 
            else
            {
                return false;
            }
        }
        public void Clear()
        {
            Head = null; 
            Tail = null; 
            Counter = 0;
            Console.WriteLine("List Cleared.");
        }
        public void AddLast(User value)
        {
            Node AddedNode = new Node(value);
            if (Head == null)
            {
                Head = AddedNode;
                Tail = AddedNode;
                Counter++;
            }
            else
            {
                Tail.Next = AddedNode;
                Tail = AddedNode;
                Counter++;
            }
        }
        public void AddFirst(User value)
        {
            Node AddedNode = new Node(value);
            if(Head == null)
            {
                Head = AddedNode;
                Tail = AddedNode;
                Counter++;
            }
            else
            {
                AddedNode.Next = Head;
                Head = AddedNode;
                Counter++;
            }

        }
        public void Add(User value, int index)
        {
            Node CurrentNode = Head;
            int i = 0;
            try
            {
                int check = Counter - index;

                if (check <= 0 || index < 0 )
                {
                    throw new IndexOutOfRangeException();
                }
            }
            catch (Exception x) when (x is IndexOutOfRangeException)
            {
               if (x is IndexOutOfRangeException)
                {
                    Console.WriteLine(x.Message);
                }
            }
            while (i > index)
            {
                CurrentNode = CurrentNode.Next;
                i++;
            }
            Node AddedNode = new Node(value);
            AddedNode.Next = CurrentNode;
            CurrentNode = AddedNode;
            Counter++;
        }
        public void Replace(User value, int index)
        {
            Node CurrentNode = Head;
            Node AddedNode = new Node(value);
            int i = 0;
            try
            {
                int check = Counter - index;

                if (check <= 0 || index < 0)
                {
                    throw new IndexOutOfRangeException();
                }
            }
            catch (Exception x) when (x is IndexOutOfRangeException)
            {
                if (x is IndexOutOfRangeException)
                {
                    Console.WriteLine(x.Message);
                }
            }
            if (index == 1)
                Head = AddedNode;
            else
            {
                while (i > index)
                {
                    CurrentNode = CurrentNode.Next;
                    i++;
                }
                CurrentNode.user = AddedNode.user;
            }
        }
        public int Count()
        {
            return Counter;
        }
        public void RemoveFirst()
        {
            Node CurrentNode = Head;
            CurrentNode.user = null;
            CurrentNode.Next = null;
            Counter--;
        }
        public void RemoveLast()
        {
            Node CurrentNode = Head;
            int i = 0;
            while (i < (Counter-1))
            {
                CurrentNode = CurrentNode.Next; 
            }
            CurrentNode.user = null;
            CurrentNode.Next = null;
            Counter--;
        }
        public void Remove(int index)
        {
            try
            {
                int check = Counter - index;
                if (check <= 0 || index < 0)
                {
                    throw new IndexOutOfRangeException();
                }
            }
            catch (Exception x) when (x is IndexOutOfRangeException)
            {
                if (x is IndexOutOfRangeException)
                {
                    Console.WriteLine(x.Message);
                }
            }
            Node CurrentNode = Head;
            int i = 0;
            while (i < (Counter-1))
            {
                CurrentNode = CurrentNode.Next;
            }
            CurrentNode.Next = CurrentNode.Next.Next;
        }
        public User GetValue(int index) 
        {
            if (index == 0)
            {
                return Head.user;
            }
            else
            {
                Node node = Head;
                int i = 0;
                while (i < index)
                {
                    node = node.Next;
                    i++;    
                }
                return node.user;
            }

        }
        public int IndexOf(User value) 
        {
            return 2;
        }
        public bool Contains(User value) 
        {
            return true;
        }
        public void JoinLists(ILinkedListADT baseList, ILinkedListADT addedList)
        {
            int i = addedList.Count();
            
            while (i > 0)
            {
                User tempUser = addedList.GetValue(i);
                baseList.AddLast(tempUser);
            }
        }
    }
}
