﻿using Assignment3;

namespace Assignment3.Tests
{
    public class LinkedListTest
    {
        private ILinkedListADT users;
        private readonly string testFileName = "LLtest_users.bin";
        //(1, "Joe Blow", "jblow@gmail.com", "password") basic data format
        [SetUp]
        public void setup()
        {
            this.users = new SLL();
            users.AddLast(new User(0, "G'raha Tia", "crystalexarch@hotmail.com", "password"));
            users.AddLast(new User(1, "Thancred Waters", "thancredwaters@outlook.com", "password"));
            users.AddLast(new User(2, "Tataru Taru", "strongestscion@gmail.com", "password"));
            users.AddLast(new User(3, "Y'shtola Rhul", "mastermatoya@gmail.com", "password"));
        }
        [Test]
        public void clearTest()
        {
            this.users.Clear();
        }
        [Test]
        public void isEmptyTest()
        {
            this.users.IsEmpty();
        }
        [Test]
        public void prependTest()
        {
            users.AddLast(new User(4, "Estinien Varlineau", "azuredragoon21@gmail.com", "password"));
        }
        [Test]
        public void appendTest()
        {
            users.AddFirst(new User(5, "Alphinaud Leveilleur", "alphinaudL@gmail.com", "password"));
        }
        [Test]
        public void insertAtTest()
        {
            users.Add(new User(6, "Urianger Augurelt", "kingofpixies@hotmail.com", "password"), 2);
        }
        [Test]
        public void replaceTest()
        {
            users.Replace(new User(7, "Alisae Leveilleur", "bettertwin23@gmail.com", "password"), 1);
        }
        [Test]
        public void fetchInfoTest()
        {
            users.GetValue(3);
        }
        [Test]
        public void removeFromBeginningTest()
        {
            users.RemoveFirst();
        }
        [Test]
        public void removeFromLastTest()
        {
            users.RemoveLast();
        }
        [Test]
        public void removeFromIndex()
        {
            users.Remove(0);
        }
    }
}
